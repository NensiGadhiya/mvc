<?php
class Model_Core_Table_Row 
{
	protected $tableClass = 'Model_Core_Table';
	protected $tableName = null;
	protected $primaryKey = null;
	protected $data=[];
	protected $table = null;
	

	public function __set($key,$value){
		$this->data[$key] = $value;
	}

	public function __get($key){
		if(array_key_exists($key, $this->data))
		{
			return $this->data[$key];
		}
		return null;
	}

	public function __unset($key)
	{
		if (array_key_exists($key,$this->data)) {
			unset($this->data[$key]);
		}
		return $this;
	}

	public function getTableName()
	{
		return $this->getTable()->getTableName();
	}

	public function getPrimaryKey()
	{
		return $this->getTable()->getPrimaryKey();
	}

	public function setTable($table)
	{
		$this->table = $table;
		return $this;
	}

	public function getTable()
	{
		$tableClass = $this->tableClass;
		if ($this->table!=null) {
			return $this->table;
		}
		$model = new $tableClass();
		$this->setTable($model);
		return $model;
	}


	public function setData($data)
	{
		$this->data = $data;
		return $this;
	}

	public function getData($key=null)
	{
		if ($key == null) {
		return $this->data;
		}
		if(array_key_exists($key, $this->data))
		{
			return $this->data[$key];
		}
		return null;
	}

	public function addData($key,$value)
	{
		$this->data[$key] = $value;
		return $this;
	}
	public function removeData($key=null)
	{
		if ($key == null) {
			$this->data = [];
		}
		if(array_key_exists($key,$this->data)) {
			unset($this->data[$key]);
		}
		return $this;
	}

	public function save()
	{
		$table = $this->getTable();
		$request= new Model_Core_Request(); 

		if($request->getParam($this->getPrimaryKey())){
			$id = $request->getParam($this->getPrimaryKey());
			$table->setTableName($this->getTableName());
			$table->setPrimaryKey($this->getPrimaryKey());
			$result=$table->update($this->data, $id);
			return $result;
		}
			else{
			$table->setTableName($this->tableName);
			$result = $table->insert($this->data);

			$this->load($result);
		  return $result;
		}


		// if (array_key_exists($this->getPrimaryKey(), $this->data)) {
		// 	$condition = [$this->getPrimaryKey() => $this->data[$this->getPrimaryKey()]];
		// 	$result = $this->getTable()->update($this->data, $condition);
		// 	if ($result) {
		// 		return $this->load($this->data[$this->getPrimaryKey()]);
		// 	}
		// 	return false;

		// } else {
		// 	$insertId = $this->getTable()->insert($this->data);
		// 	if ($insertId) {
		// 		return $this->load($insertId);
		// 	}
		// 	return false;
		// }

	}
		

	public function fetchAll($query)
	{
		
		$result = $this->getTable()->fetchAll($query);
		if (!$result) {
			return false;
		}
		foreach ($result as &$row) {
			$row =  (new $this)->setData($row)->setTable($this->getTable());
		}
		return $result;
	}

	public function load($id,$column=null)
	{
		if (!$column) {
			$column = $this->getPrimaryKey();
		}
		$sql = "SELECT * FROM `{$this->getTableName()}` WHERE `{$column}` = '{$id}'";

		$result = $this->getTable()->fetchRow($sql);
		if ($result) {
			$this->data = $result;
		}
		return $this;
	}

	public function fetchRow($query)
	{
		$row = $this->getTable()->fetchRow($query);
		if ($row) {
			$this->data = $row;
			return $this;
		}
		return false;
	}

	public function delete()
	{
		$id = $this->getData($this->getPrimaryKey());
		if (!$id) {
			return false;
		}
		$this->getTable()->delete($id);
		return $this;
	}
}
