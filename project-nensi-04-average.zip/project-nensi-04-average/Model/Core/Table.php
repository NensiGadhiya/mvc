<?php

require_once 'Adapter.php';

class Model_Core_Table
{
	protected $data= [];
	protected $tableName= null;
	protected $primaryKey= null;
	protected $adapter= null;
	

	public function setAdapter($adapter)
	{
		$this->adapter= $adapter;
		return $this;
	}

	public function getAdapter()
	{
		if ($this->adapter) 
		{
			return $this->adapter;
		}

		$adapter= new Model_Core_Adapter();
		$this->setAdapter($adapter);
		return $adapter;
	}

	public function getTableName()
	{
		return $this->tableName;
	}

	public function setTableName($tableName)
	{
		$this->tableName= $tableName;
		return $this;
	}

	public function getPrimaryKey()
	{
		 return $this->primarykey;
	}

	public function setPrimaryKey($primaryKey)
	{
		$this->primaryKey= $primaryKey;
		return $this;
	}

	public function fetchAll($query=null)
	{
		$adapter= $this->getAdapter();
		if ($query == null) 
		{
			$sql= "SELECT * FROM `{$this->tableName}`";
			$result= $adapter->fetchAll($sql);
		}
		else
		{
			$result = $adapter->fetchAll($query);
		}
		return $result;
	}

	public function fetchRow($query=null)
	{
		if ($query==null) 
		{
			$sql="SELECT * FROM `{$this->tableName}` WHERE `{$this->primarykey}`={$id}";
			$adapter= $this->getAdapter();
			$result= $adapter->fetchRow($sql);	
		}
		else
		{
			$adapter= $this->getAdapter();
			$result= $adapter->fetchRow($query);
		}
		return $result;
	}

	public function insert($data)
	{
		if (is_array($data)) 
		{
			$key = implode('`,`', array_keys($data));
			$value = implode('\',\'',$data);
			$sql="INSERT INTO `{$this->gettableName()}` (`{$key}`) VALUES ('{$value}')";
			return $this->getAdapter()->insert($sql);
			
		}
	}

	public function update($data, $condition)
	{
		$where=[];
		if (is_array($data)) 
		{
			foreach ($data as $key => $value) 
			{
				$where[]="`$key`='$value'";
			}
		}

		$conditions = [];
		if (is_array($condition)) {
			foreach ($condition as $key => $value) {
				$conditions[]="`{$key}`='{$value}'";
			// print_r($conditions);
			}
			echo $query="UPDATE `{$this->tableName}` SET". implode(',',$where)."WHERE".implode('AND', $conditions);
		}else{
		
		$sql="UPDATE `{$this->tableName}` SET".implode(',',$where)."WHERE `{$this->primaryKey}`='{$condition}'";
	}
		return $this->getAdapter()->update($sql);
	}

	public function delete($condition)
	{
		$sql= "DELETE FROM `{$this->tableName}` WHERE `{$this->getPrimaryKey()}`='{$condition}'";
		print_r($sql);
		$adapter=$this->getAdapter();
		$adapter->delete($sql);
	}
}
?>
