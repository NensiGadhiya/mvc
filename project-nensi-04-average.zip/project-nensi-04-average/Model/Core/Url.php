<?php

class Model_Core_Url
{
	public function getCurrentUrl()
	{
		return "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	}

	public function getUrl($controller=null,$action=null,$params=[],$reset=false)
	{
		// echo $requestUrl= "http://". $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];


		$request= new Model_Core_Request();

		$final=$request->getParam();

		// $final= [];


		if ($reset) {
			$final=[];
		}
		if ($controller) {
			$final['c']= $controller;
		}
		else
		{
			$final['c']= $request->getControllerName();
		}
		if ($action) {
			$final['a']= $action;
		}
		else
		{
			$final['a']= $request->getActionName();
		}
		if ($params) {
			$final= array_merge($final,$params);
		}



		$queryString= http_build_query($final);



		
		$requestUri= trim($_SERVER['REQUEST_URI'],$_SERVER['QUERY_STRING']);



		$url = $_SERVER['REQUEST_SCHEME']."://". $_SERVER['HTTP_HOST'] . $requestUri .$queryString ;

		return $url;
	}
}


?>