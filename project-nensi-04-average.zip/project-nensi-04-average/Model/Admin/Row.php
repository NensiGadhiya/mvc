<?php

/**
 * 
 */
class Model_Admin_Row extends Model_Core_Table_Row
{
	public $tableClass = "Model_Product";

	public function getStatusText()
	{
		$statuses = $this->getTable()->getStatusOptions();
		if (array_key_exists($this->status, $statuses)) 
		{
			return $statuses[status];
		}

		return $statuses[Model_Admin::STATUS_DEFAULT];

	}
}