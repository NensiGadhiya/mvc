<?php
require 'Model/Core/Table.php';
/**
 * 
 */
class Model_Category extends Model_Core_Table
{
	const STATUS_YES=1;
	const STATUS_NO=2;
	const STATUS_YES_LBL='Yes';
	const STATUS_NO_LBL='No';
	const STATUS_DEFAULT=2;
	
	public $tableName='category';
	public $primarykey='category_id';
}


?>