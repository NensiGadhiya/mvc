<?php

/**
 * 
 */
class Model_Admin extends Model_Core_Table
{
	protectd $tableName = "admin";
	protectd $primaryKey = "admin_id";

	// public function getStatusOptions()
	// {
	// 	return [
	// 		self::STATUS_ACTIVE => self::STATUS_ACTIVE_LBL,
	// 		self::STATUS_INACTIVE => self::STATUS_INACTIVE_LBL
	// 	];
	// }

	// function __construct()
	// {
	// 	parent::__construct();

	// 	$this->setTableName('admin')->setPrimaryKey('admin_id');
	// }
}