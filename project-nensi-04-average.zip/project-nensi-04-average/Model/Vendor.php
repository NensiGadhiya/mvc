<?php
require 'Model/Core/Table.php';

/**
 * 
 */
class Model_Vendor extends Model_Core_Table
{
	
	public $tableName='vendor';
	public $primarykey='vendor_id';
}

?>