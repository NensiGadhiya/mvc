<?php
require_once 'Model/Core/Table/Row.php';

class Model_Customer_Address_Row extends Model_Core_Table_Row
{
	protected $tableName  = 'customer_address';
	protected $primaryKey = 'address_id';
	protected $tableClass = 'Model_Customer_Address';
	const STATUS_ACTIVE = 'yes';
	const STATUS_ACTIVE_LBL = 'Active';
	const STATUS_INACTIVE = 'no';
	const STATUS_INACTIVE_LBL = 'Inactive';

	public function getStatusOptions()
	{
		return [
			self::STATUS_ACTIVE => self::STATUS_ACTIVE_LBL,
			self::STATUS_INACTIVE => self::STATUS_INACTIVE_LBL
		];
	}
}
?>