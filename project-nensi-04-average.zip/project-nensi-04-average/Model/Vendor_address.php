<?php
require_once 'Model/Core/Table.php';

/**
 * 
 */
class Model_Vendor_Address extends Model_Core_Table
{
	
	public $tableName='vendor_address';
	public $primarykey='address_id';
}


?>