<?php
require_once 'Model/Core/Table.php';

/**
 * 
 */
class Model_Salesman_Price extends Model_Core_Table
{
	
	public $tableName = 'salesman_price';
	public $primarykey = 'entity_id';
	
}


?>