<?php
// require_once 'Core/Table.php';

/**
 * 
 */
class Model_Product extends Model_Core_Table
{
	const STATUS_ACTIVE = 1;
	const STATUS_ACTIVE_LBL ='Yes';
	const STATUS_INACTIVE = 2;
	const STATUS_INACTIVE_LBL ='No';
	// const STATUS_DEFAULT =2;
	
	 public $tablename = "product";
	 public $primarykey = "product_id";

	 public function getStatusOptions()
	{
		return[
				self::STATUS_ACTIVE=>self::STATUS_ACTIVE_LBL,
				self::STATUS_INACTIVE=>self::STATUS_INACTIVE_LBL,
		];
	}
}

?>