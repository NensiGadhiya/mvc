<?php
require_once 'Model/Core/Table/Row.php';

class Model_Media_Row extends Model_Core_Table_Row
{
	protected $tableName  = 'media';
	protected $primaryKey = 'media_id';
	protected $tableClass = 'Model_Product_Media';
	
}
?>