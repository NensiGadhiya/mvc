<?php

require 'Model/Core/Table.php';

/**
 * 
 */
class Model_Customer extends Model_Core_Table
{
	
	public $tableName= 'customer';
	public $primarykey= 'customer_id';
}

?>