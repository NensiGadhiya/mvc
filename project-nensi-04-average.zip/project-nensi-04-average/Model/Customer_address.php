<?php
require_once 'Model/Core/Table.php';

/**
 * 
 */
class Model_Customer_Address extends Model_Core_Table
{
	
	public $tableName='customer_address';
	public $primarykey='address_id';
}


?>