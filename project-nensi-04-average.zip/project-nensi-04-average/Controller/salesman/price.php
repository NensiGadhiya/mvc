<?php
require_once 'Controller/Core/Action.php';
require_once 'Model/Salesman_price.php';

/**
 * 
 */
class Controller_Salesman_Price extends Controller_Core_Action
{
	
	protected $price = null;
	protected $priceId = null;
	protected $priceModel = null;

	public function setPrice($price)
	{
		$this->price= $price;
		return $this;
	}

	public function getPrice()
	{
		return $this->price;
	}

	public function setPriceId()
	{
		$this->priceId= $priceId;
		return $this;
	}

	public function getPriceId()
	{
		return $this->priceId;
	}

	public function setPriceModel($priceModel)
	{
		$this->priceModel= $priceModel;
		return $this;
	}

	public function getPriceModel()
	{
		if ($this->priceModel != null) {
			return $this->priceModel;
		}
		$priceModel= new Model_Salesman_Price();
		$this->setPriceModel($priceModel);
		return $priceModel;
	}

	public function gridAction()
	{
		
	}
}







?>