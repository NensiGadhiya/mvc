<?php
require_once 'Controller/Core/Action.php';
require_once 'Model/salesman_address.php';


class Controller_Salesman_Address extends Controller_Core_Action
{
	protected $address = null;
	protected $addressId = null;
	protected $addressModel = null;


	public function setAddress($address)
	{
  	   $this->address= $address;
  	   return $this;
	}

   public function getAddress()
   {
      return $this->address;	  
   }

   public function setAddressId()
   {

   	$this->addressId= $addressId;
   	return $this;
   }

   public function getAddressId()
   {
   	return $this->addressId;
   }

   public function setAddressModel($addressModel)
   {
   	$this->addressModel= $addressModel;
   	return $this;
   }

   public function getAddressModel()
   {
   	if ($this->addressModel != null) 
   	{
   		return $this->addressModel;
   	}
   	$addressModel= new Model_Salesman_Address();
   	$this->setAddressModel($addressModel);
   	return $addressModel;

   }

	public function gridAction()
	{
		$this->getAddressModel()->setTableName("salesman_address");
		$address= $this->getAddressModel()->fetchAll(null);
		$this->setAddress($address);

	  require_once 'View/salesman_address/grid.phtml';	
	}

	public function addAction()
	{
		$this->getTemplate('salesman_address/add.phtml');
	}

	public function editAction()
	{
		$id=$this->getAddressModel()->fetchAll();
		$sql="SELECT * FROM `salesman_address` WHERE `salesman_id`='$id'";
		$address=$this->getAddressModel()->fetchRow(null,$sql);
		$this->setaddress($address);
		$this->getTemplate('salesman_address/edit.phtml');
		
	}

	

	public function deleteAction()
	{
		$condition= $this->getRequest()->getParam('address_id');
		print_r($condition);

		$address= $this->getAddressModel()->delete($condition);
		$this->redirect("index.php?c=salesman_address&a=grid");
	}

	public function updateAction()
	{
		$address= $this->getRequest()->getPost('salesmanAdd');
		$this->getAddressModel()->update($address,$address['address_id']);

		$this->redirect("index.php?c=salesman_address&a=grid");
	}

	public function errorAction($action)
	{
		throw new Exception("method:{$action} does not exists.", 1);
		
	}
	public function redirect($url = NULL)
	{
		header("location: {$url}");
	}


}


?>