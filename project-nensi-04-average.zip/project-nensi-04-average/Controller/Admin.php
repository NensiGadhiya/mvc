<?php

/**
 * 
 */
class Controller_Admin extends Controller_Core_Action
{
	public $adminRow = null;

	public function setAdminRow($adminRow)
	{
		$this->adminRow = $adminRow;
		return $this; 
	}

	public function getAdminRow()
	{
		if($this->adminRow!=null)
		{
   		return $this->adminRow;
   	    }
   	    $adminRow = Ccc::getModel('admin_row');
   	    $this->setAdminRow($adminRow);
   	    return $adminRow;	
	}

	public function gridAction()
	{
		
	}
}