<?php
require_once'Controller/Core/Action.php';
require_once 'Model/Vendor.php';
require_once 'Model/vendor_address.php';
require_once 'Model/Core/Message.php';

/**
 * 
 */
class Controller_Vendor extends Controller_Core_Action
{
	
	protected $vendor= null;
	protected $vendorId= null;
	protected $vendorModel= null;
	protected $addressModel= null;
	

	public function setVendor($vendor)
	{
		$this->vendor= $vendor;
		return $this;
	}

	public function getVendor()
	{
		return $this->vendor;
	}

	public function setVendorId()
	{
		$this->vendorId= $vendorId;
		return $this;
	}

	public function getVendorId()
	{
		return $this->vendorId;
	}

	public function setVendorModel($vendormodel)
	{
		$this->vendorModel= $vendorModel;
		return $this;
	}

	public function getVendorModel()
	{

		if ($this->vendorModel !=null) 
		{
			return $this->vendorModel;
		}

		$vendorModel= new Model_Vendor();
		$this->setVendorModel= ($vendorModel);
		return $vendorModel;
	}

	public function setAddressModel($addressModel)
    {
   		$this->addressModel= $addressModel;
   		return $this;
    }

   public function getAddressModel()
    {
	   	if ($this->addressModel != null) 
	   	{
	   		return $this->addressModel;
	   	}

	   	$addressModel= new Model_Vendor_Address();
	   	$this->setAddressModel($addressModel);
	   	return $addressModel;

    }

	public function gridAction()
	{
		$this->getVendorModel()->setTableName("vendor");
		$vendor= $this->getVendorModel()->fetchAll(null);
		$this->setVendor($vendor);

		require_once 'View/vendor/grid.phtml';
	}

	public function addAction()
	{
		$this->getTemplate('vendor/add.phtml');
	}

	public function editAction()
	{
		try{
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
			
		}	
		$id= $request->getParam('vendor_id');
		if (!$id) {
			throw new Exception("row not found", 1);
		}
		$vendor = $this->getVendorModel()->fetchRow($id);
		$this->setVendor($vendor);
		$this->getTemplate('vendor/edit.phtml');

		}catch(Exception $e){
		$message = new Model_Core_Message();
		$message->addMessage("Data not found",Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=vendor&a=grid");
	}
	}

	public function insertAction()
	{
		try {
		 $request=$this->getRequest();
		 if (!$request) {
		 	throw new Exception("Invalid Request", 1);
		 }
		 $vendor = $request->getPost('vendor');
		 $id = $this->getVendorModel()->insert($vendor);
		 if (!$id) {
		 	throw new Exception("Id not found", 1);
		 }
		 $data=$this->getRequest()->getPost('vendor_address');
		 $data['vendor_id']=$id;
		 $this->getAddressModel()->insert($data);
		 $message = new Model_Core_Message();
		 $message->addMessage("Data Inserted Successfully.", Model_Core_Message::SUCCESS);
		 $this->redirect("index.php?a=grid&c=vendor");
			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
		 	$message->addMessages("Data Not Inserted.", Model_Core_Message::FAILURE);
		 	$this->redirect("index.php?a=grid&c=vendor");
		}
	}
	public function deleteAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$vendor = $request->getParam('vendor_id');
		if (!$vendor) {
			throw new Exception("row not found", 1);
		}
		$vendor= $this->getVendorModel()->delete($vendor);
		$message = new Model_Core_Message();
		$message->addMessage('vendor delete successfully', Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=vendor&a=grid");
			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('vendor delete successfully', Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=vendor&a=grid");
		}
	}

	public function updateAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$vendor = $request->getPost('vendor');
		$vendor['updated_at']= date('y-m-d h:i:sa');
		if (!$vendor) {
			throw new Exception("Row not found", 1);
		}
		$this->getVendorModel()->update($vendor,$vendor['vendor_id']);
		$message = new Model_Core_Message();
		$message->addMessage('vendor update successfully', Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=vendor&a=grid");
			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('vendor update successfully', Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=vendor&a=grid");
		}
	}

	public function errorAction($action)
	{
		throw new Exception("method:{$action} does not exists.", 1);

	}

	public function redirect($url = null)
	{
		header("location: {$url}");
	}


}

?>