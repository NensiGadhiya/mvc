<?php
require_once'Controller/Core/Action.php';
require_once 'Model/Payment.php';
require_once 'Model/Core/url.php';
require_once 'Model/Core/Message.php';
/**
 * 
 */
class Controller_Payment extends Controller_Core_Action
{
	
	protected $payment= null;
	protected $paymentId= null;
	protected $paymentModel= null;

	public function setPayment($payment)
	{
		$this->payment= $payment;
		return $this;
	}

	public function getpayment()
	{
		return $this->payment;
	}

	public function setPaymentId()
	{
		$this->paymentId= $paymentId;
		return $this;
	}

	public function getPaymentId()
	{
		return $this->paymentId;
	}

	public function setPaymentModel($paymentmodel)
	{
		$this->paymentModel= $paymentModel;
		return $this;
	}

	public function getpaymentModel()
	{

		if ($this->paymentModel !=null) 
		{
			return $this->paymentModel;
		}

		$paymentModel= new Model_Payment();
		$this->setPaymentModel= ($paymentModel);
		return $paymentModel;
	}

	public function gridAction()
	{
		try {
		$payment= $this->getPaymentModel()->fetchAll();
		if (!$payment) {
			throw new Exception("Data not found", 1);
		}
		$this->setPayment($payment);
		$this->getTemplate('payment/grid.phtml');			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("Data not posted",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=payment&a=grid");
		}
	}

	public function addAction()
	{
		$this->getTemplate('Payment/add.phtml');
	}

	public function editAction()
	{
		try{
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$id = $request->getParam('payment_id');
		if (!$id) {
			throw new Exception("Row not found", 1);
		}
		$payment=$this->getPaymentModel()->fetchRow($id);
		$this->setPayment($payment);
		$this->getTemplate('Payment/edit.phtml');
		}catch(Exception $e){
		$message = new Model_Core_Message();
		$message->addMessage("Data not found", Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=payment&a=grid");
	}
	}

	public function insertAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$payment = $request->getPost('payment');
		if (!$payment) {
			throw new Exception("payment not found", 1);
		}
			$id= $this->getPaymentModel()->insert($payment);
			$message = new Model_Core_Message();
			$message->addMessage('Payment insert successfully',Model_Core_Message::SUCCESS);
			$this->redirect("index.php?c=payment&a=grid");		
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('Payment insert successfully',Model_Core_Message::FAILURE);			
			$this->redirect("index.php?c=payment&a=grid");
		}

	}

	public function deleteAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$payment = $request->getParam('payment_id');
		if (!$payment) {
			throw new Exception("Row not found", 1);
		}
		$payment= $this->getPaymentModel()->delete($payment);
		$message = new Model_Core_Message();
		$message->addMessage('Payment delete successfully',Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=payment&a=grid");
		} catch (Exception $e) {
		$message = new Model_Core_Message();
		$message->addMessage('Payment delete successfully',Model_Core_Message::FAILURE);			
		$this->redirect("index.php?c=payment&a=grid");
		}
	}

	public function updateAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$payment = $request->getPost('payment');
		$payment['updated_at']= date('y-m-d h:i:sa');
		if (!$payment) {
			throw new Exception("Row not found", 1);
		}
		$this->getPaymentModel()->update($payment,$payment['payment_id']);
		$message = new Model_Core_Message();
		$message->addMessage('Payment update successfully',Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=payment&a=grid");			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('Payment update successfully',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=payment&a=grid");
		}
	}

	public function errorAction($action)
	{
		throw new Exception("method:{$action} does not exists.", 1);

	}

	public function redirect($url = null)
	{
		header("location: {$url}");
	}


}

?>