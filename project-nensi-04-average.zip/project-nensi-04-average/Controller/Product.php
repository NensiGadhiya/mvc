<?php

class Controller_Product extends Controller_Core_Action
{

	protected $products= [];
	protected $productId= null;
	protected $productModel= null;
	protected $productRow = null;

	public function setProducts($product)
	{
  	   $this->products= $product;
  	   return $this;
	}

    public function getProducts()
	{
	  return $this->products;	  
	}

   public function setProductId($productId)
   {
   	$this->productId= $productId;
   	return $this;
   }

   public function getProductId($value="")
   {
   	return $this->productId;
   }

   public function setProductRow($productRow)
   {
   	$this->productRow = $productRow;
   	return $this;
   }

   public function getProductRow()
   {
   	if($this->productRow!=null){
   		return $this->productRow;
   	}
   	$productRow = new Model_Product_Row();
   	$this->setProductRow($productRow);

   	return $productRow;
   }

   public function setProductModel($productModel)
   {

   	$this->productModel= $productModel;
   	return $this;
   }

	public function getProductModel()
	{
		if ($this->productModel != null) 
		{
			return $this->productModel;
		}
		$productModel= new Model_Product();
		$this->setProductModel($productModel);
		return $productModel;
	}

	public function gridAction()
		{	
			try {
		$product = Ccc::getModel('Product_Row');
				$query = "SELECT * FROM `product`";
				$products = $product->fetchAll($query);
				if (!$products) {
					throw new Exception("Product not found", 1);
				}
				
				$this->getView()->setTemplate('product/grid.phtml')->setData(['products' =>$products]);
				$this->render();
		} catch (Exception $e) {
			$message = new Model_Core_Message();
		$message->addMessage("product not found",Model_Core_Message::FAILURE);
			$this->redirect("index.php?a=grid&c=product");
		}
	}

	public function addAction()
	{

		try {
			$product = Ccc::getModel('Product_Row');
			if (!$product) {
				throw new Exception("Product not found", 1);
			}
			$this->getView()->setTemplate('product/edit.phtml')->setData(['products' => $product])->render();
		} catch (Exception $e) {
			
		}
	}

	public function editAction()
	{	
		try {
				$product = Ccc::getModel('Product_Row');
				$request=$this->getRequest();
				if (!$request) {
					throw new Exception("Invalid Request", 1);
				}
				$id = $request->getParam('product_id');
				if (!$id) {
					throw new Exception("Id not found", 1);
				}
				$row = $product->load($id,'product_id');
				if (!$row) {
						throw new Exception("Data not found", 1);
				}
				$this->getView()->setTemplate('product/edit.phtml')->setData(['products' =>$row]);
				$this->render();
		}
		catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('data not found',Model_Core_Message::FAILURE);
			$this->redirect("index.php?a=grid&c=product");
		}
	}

	public function saveAction()
	{
		
		try {
				$product = Ccc::getModel('Product_Row');
					$request=$this->getRequest();
					if (!$request->isPost()){
				throw new Exception("Invalid Request", 1);
					}
					$products = $request->getPost('product');
					if (!$products) {
						throw new Exception("Data not posted", 1);
					}
					$id = $request->getParam('product_id');
					if(!$id){
						if(!$product->load($id)){
							throw new Exception("Data not found.", 1);
						}
					}
					$data = $product->setData($products);
					if ($data->product_id) {
						$data->update_at = date('Y-m-d h:i:sa');
					}
					else{
						$data->create_at = date('Y-m-d h:i:sa');
					}
					$data = $product->save();
					$message = new Model_Core_Message();
					$message->addMessage("Product saved successfully.",Model_Core_Message::SUCCESS);
				$this->redirect("index.php?a=grid&c=product");
				
			} catch (Exception $e) {
				$message = new Model_Core_Message();
				$message->addMessage("Product not saved.",Model_Core_Message::FAILURE);
				$this->redirect("index.php?a=grid&c=product");
			}
	}

	
	public function deleteAction()
	{
		
		try {
			$product = Ccc::getModel('Product_Row');
				$request = $this->getRequest();
				if (!$request->isGet())
				{
					throw new Exception("Invalid request", 1);
				}
				$id = $request->getParam('product_id');
				if (!$id)
				{
					throw new Exception("id not found", 1);
				}
				$product->load($id);
				$product->delete();
				$message = new Model_Core_Message();
				$message->addMessage("product deleted successfully..",Model_Core_Message::SUCCESS);
				$this->redirect("index.php?a=grid&c=product");
			}catch (Exception $e)
			{
				$message = new Model_Core_Message();
				$message->addMessage("row not delete",Model_Core_Message::SUCCESS);
				$this->redirect("index.php?a=grid&c=product");
			}
	}
}
?>	