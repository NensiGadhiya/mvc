<?php
require_once 'Controller/Core/Action.php';
require_once 'Model/Shipping.php';
require_once 'Model/Core/url.php';
require_once 'Model/Core/Message.php';


class Controller_Shipping extends Controller_Core_Action
{
	protected $shipping= null;
	protected $shippingId= null;
	protected $shippingModel= null;


	public function setShipping($shipping)
	{
  	   $this->shipping= $shipping;
  	   return $this;
	}

   public function getShipping()
   {
      return $this->shipping;	  
   }

   public function setShippingId()
   {

   	$this->shippingId= $shippingId;
   	return $this;
   }

   public function getShippingId()
   {
   	return $this->shippingId;
   }

   public function setShippingModel($shippingModel)
   {
   	$this->shippingModel= $shippingModel;
   	return $this;
   }

   public function getShippingModel()
   {
   	if ($this->shippingModel != null) 
   	{
   		return $this->shippingModel;
   	}
   	$shippingModel= new Model_Shipping();
   	$this->setShippingModel($shippingModel);
   	return $shippingModel;
   }

	public function gridAction()
	{
		try {
		$shipping= $this->getShippingModel()->fetchAll();
		if (!$shipping) {
			throw new Exception("Data not found", 1);
		}
		$this->setShipping($shipping);
		$this->getTemplate('shipping/grid.phtml');			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("Data not posted",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=shipping&a=grid");
		}
	}

	public function addAction()
	{
		$this->getTemplate ('Shipping/add.phtml');
	}

	public function editAction()
	{
		try{
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$id = $request->getParam('shipping_id');
		if (!$id) {
			throw new Exception("Row not found", 1);
		}
		$shipping=$this->getShippingModel()->fetchRow($id);
		$this->setShipping($shipping);
		$this->getTemplate('shipping/edit.phtml');
		}catch(Exception $e){
		$message = new Model_Core_Message();
		$message->addMessage("Data not found", Model_Core_Message::FAILURE);
		$this->redirect("index.php?c=shipping&a=grid");
		}
	}

	public function insertAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$shipping = $request->getPost('shipping');
		if (!$shipping) {
			throw new Exception("shipping not found", 1);
		}
			$id = $this->getShippingModel()->insert($shipping);
			$message = new Model_Core_Message();
			$message->addMessage('shipping insert successfully',Model_Core_Message::SUCCESS);
			$this->redirect("index.php?c=shipping&a=grid");		
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('shipping insert successfully',Model_Core_Message::FAILURE);			
			$this->redirect("index.php?c=shipping&a=grid");
		}
	}

	public function deleteAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$shipping = $request->getParam('shipping_id');
		if (!$shipping) {
			throw new Exception("Row not found", 1);
		}
		$shipping= $this->getShippingModel()->delete($shipping);
		$message = new Model_Core_Message();
		$message->addMessage('shipping delete successfully',Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=shipping&a=grid");
		} catch (Exception $e) {
		$message = new Model_Core_Message();
		$message->addMessage('shipping delete successfully',Model_Core_Message::FAILURE);			
		$this->redirect("index.php?c=shipping&a=grid");
		}
	}

	public function updateAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$shipping = $request->getPost('shipping');
		$shipping['updated_at']= date('y-m-d h:i:sa');
		if (!$shipping) {
			throw new Exception("Row not found", 1);
		}
		$this->getShippingModel()->update($shipping,$shipping['shipping_id']);
		$message = new Model_Core_Message();
		$message->addMessage('shipping update successfully',Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=shipping&a=grid");			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('shipping update successfully',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=shipping&a=grid");
		}
	}

	public function errorAction($action)
	{
		throw new Exception("method:{$action} does not exists.", 1);
		
	}
	public function redirect($url = NULL)
	{
		header("location: {$url}");
	}


}


?>