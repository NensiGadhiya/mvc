<?php
require_once'Controller/Core/Action.php';
require_once 'Model/Salesman.php';
require_once 'Model/Salesman_address.php';
require_once 'Model/Core/url.php';
require_once 'Model/Core/Message.php';
/**
 * 
 */
class Controller_Salesman extends Controller_Core_Action
{
	
	protected $salesman= null;
	protected $salesmanId= null;
	protected $salesmanModel= null;
	protected $addressModel = null;

	public function setSalesman($salesman)
	{
		$this->salesman= $salesman;
		return $this;
	}

	public function getSalesman()
	{
		return $this->salesman;
	}

	public function setSalesmanId()
	{
		$this->salesmanId= $salesmanId;
		return $this;
	}

	public function getSalesmanId()
	{
		return $this->salesmanId;
	}

	public function setSalesmanModel($salesmanmodel)
	{
		$this->salesmanModel= $salesmanModel;
		return $this;
	}

	public function getSalesmanModel()
	{

		if ($this->salesmanModel !=null) 
		{
			return $this->salesmanModel;
		}

		$salesmanModel= new Model_Salesman();
		$this->setSalesmanModel= ($salesmanModel);
		return $salesmanModel;
	}

	public function setAddressModel($addressModel)
    {
	   	$this->addressModel= $addressModel;
	   	return $this;
    }

   public function getAddressModel()
    {
	   	if ($this->addressModel != null) 
	   	{
	   		return $this->addressModel;
	   	}
	   	
	   	$addressModel= new Model_Salesman_Address();
	   	$this->setAddressModel($addressModel);
	   	return $addressModel;

    }

	public function gridAction()
	{
		try {
		$salesman = $this->getSalesmanModel()->fetchAll();
		if (!$salesman) {
			throw new Exception("Data not found", 1);
		}
		$this->setSalesman($salesman);
		$this->getTemplate("salesman/grid.phtml");
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("Data not posted",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=salesman&a=grid");			
		}
	}

	public function addAction()
	{
		$this->getTemplate('salesman/add.phtml');
	}

	public function editAction()
	{
		try {
		$request= $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$id = $request->getParam('salesman_id');
		if (!$id) {
				throw new Exception("Row not found", 1);
		}
		$salesman=$this->getSalesmanModel()->fetchRow($id);
		$this->setSalesman($salesman);
		$this->getTemplate('salesman/edit.phtml');
					
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("Data not found",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=salesman&a=grid");
		}
	}

	public function insertAction()
	{
try {
		$request=$this->getRequest();
		if (!$request) {
		 	throw new Exception("Invalid Request", 1);
		}
		$salesman = $request->getPost('salesman');
		$id = $this->getSalesmanModel()->insert($salesman);
		if (!$id) {
		 	throw new Exception("Id not found", 1);
		}
		$data=$this->getRequest()->getPost('salesman_address');
		$data['salesman_id']=$id;
		$this->getAddressModel()->insert($data);
		$message = new Model_Core_Message();
		$message->addMessage("Data Inserted Successfully.", Model_Core_Message::SUCCESS);
		$this->redirect("index.php?a=grid&c=salesman");
			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
		 	$message->addMessages("Data Not Inserted.", Model_Core_Message::FAILURE);
		 	$this->redirect("index.php?a=grid&c=salesman");
		}
	}

	public function deleteAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$salesman = $request->getParam('salesman_id');
		if (!$salesman) {
			throw new Exception("Row not found", 1);
		}	
		$salesman = $this->getSalesmanModel()->delete($salesman);
		$message = new Model_Core_Message();
		$message->addMessage('salesman delete successfully',Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=salesman&a=grid");	
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage('salesman delete successfully',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=salesman&a=grid");
		}
	}

	public function updateAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}

		$salesman = $request->getPost('salesman');
		$salesman['updated_at']= date('y-m-d h:i:sa');
		if (!$salesman) {
			throw new Exception("Row not found", 1);
		}
		$this->getSalesmanModel()->update($salesman,$salesman['salesman_id']);
		$message = new Model_Core_Message();
		$message->addMessage('salesman update successfully',Model_Core_Message::SUCCESS);
		$this->redirect("index.php?c=salesman&a=grid");
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("salesman update successfully",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=salesman&a=grid");
		}
	}

	public function errorAction($action)
	{
		throw new Exception("method:{$action} does not exists.", 1);

	}

	public function redirect($url = null)
	{
		header("location: {$url}");
	}


}

?>