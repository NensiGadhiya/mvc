<?php
require_once'Controller/Core/Action.php';
require_once 'Model/Category.php';
require_once 'Model/Core/url.php';
require_once 'Model/Core/Message.php';
require_once 'Model/Category/Row.php';

/**
 * 
 */
class Controller_Category extends Controller_Core_Action
{
	
	protected $category= null;
	protected $categoryId= null;
	protected $categoryModel= null;
	protected $categoryRow = null;

	public function setCategory($category)
	{
		$this->category= $category;
		return $this;
	}

	public function getCategory()
	{
		return $this->category;
	}

	public function setcategoryId($categoryId)
	{
		$this->categoryId= $categoryId;
		return $this;
	}

	public function getcategoryId()
	{
		return $this->categoryId;
	}

	public function setCategoryRow($categoryRow)
	{
		$this->categoryRow = $categoryRow;
		return $this;
	}

	public function getCategoryRow()
	{
		if ($this->categoryRow) {
			return $this->categoryRow;
		}
		$categoryRow = new Model_Category_Row();
		$this->setCategoryRow($categoryRow);
		return $categoryRow;
	}

	public function setCategoryModel($categoryModel)
	{
		$this->categoryModel= $categoryModel;
		return $this;
	}

	public function getCategoryModel()
	{

		if ($this->categoryModel !=null) 
		{
			return $this->categoryModel;
		}

		$categoryModel= new Model_Category();
		$this->setCategoryModel($categoryModel);
		return $categoryModel;
	}

	public function gridAction()
	{
		try {
			$sql = "SELECT * FROM `category`";
		$category= $this->getCategoryRow()->fetchAll($sql);
		// echo "<pre>";
		// print_r($category);
		// die();

		if (!$category) {
			throw new Exception("Data not found", 1);
		}
		// $this->setCategory($category);
		$this->getView()->setTemplate('category/grid.phtml')->setData($category)->render();			
		} catch (Exception $e) {
			$message = new Model_Core_Message();
			$message->addMessage("Data not posted",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=category&a=grid");
		}
	}

	public function addAction()
	{
		$query = " SELECT * FROM `category`";
		$category = $this->getCategoryRow()->fetchAll($query);
		// $this->setCategory($category);
		$this->getView()->setTemplate('category/add.phtml')->render();
	}

	public function editAction()
	{
		try {
		$request = $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$id = $request->getParam('category_id');
		if (!$id) {
			throw new Exception("row not found", 1);
		}

		$row = $this->getCategoryRow()->load($id, 'category_id');
		if (!$row) {
			throw new Exception("No data found", 1);
		}

		$this->setCategory($row);
		$this->getTemplate('category/edit.phtml');
		} catch (Exception $e) {

			$message = new Model_Core_Message();
			$message->addMessage("Data not found",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=category&a=grid");
		}	
	}

	public function insertAction()
	{
		try {
		$request= $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
			$category = $request->getPost('category');

		if (!$category) {
				throw new Exception("category not Found", 1);
		}

			$this->getCategoryRow()->setData($category)->save();

			$message= new Model_Core_Message();
			$message->addMessage('Inserted successfully.',Model_Core_Message::SUCCESS);
			$this->redirect("index.php?c=category&a=grid");
	
		} catch (Exception $e) 
		{
			$message = new Model_Core_Message();
			$message->addMessage("Data not found.",Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=category&a=grid");

		}
	}


	public function updateAction()
	{
		try {
		$request= $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}
		$category = $request->getPost('category');
		$category['updated_at']= date('y-m-d h:i:sa');
		if (!$category) {
			throw new Exception("Row not found", 1);
		}
		
		$this->getCategoryRow()->setData($category);
		$this->getCategoryRow()->save();

			$message= new Model_Core_Message();
			$message->addMessage('category update successfully',Model_Core_Message::SUCCESS);
			$this->redirect("index.php?c=category&a=grid");	
		} catch (Exception $e) 
		{
			$message= new Model_Core_Message();
			$message->addMessage('category update successfully',Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=category&a=grid");

		}

	}

	public function deleteAction()
	{
		try {
		$request= $this->getRequest();
		if (!$request) {
			throw new Exception("Invalid Request", 1);
		}

		$category = $request->getParam('category_id');
		if (!$category) {
			throw new Exception("row not found", 1);
		}

			$this->getCategoryRow()->load($category);
			$this->getCategoryRow()->delete();

			$message= new Model_Core_Message();
			$message->addMessage('category delete successfully', Model_Core_Message::SUCCESS);
			$this->redirect("index.php?c=category&a=grid");
		} catch (Exception $e) 
		{
			$message= new Model_Core_Message();
			$message->addMessage('category not delete', Model_Core_Message::FAILURE);
			$this->redirect("index.php?c=category&a=grid");
		}
	}
}

?>