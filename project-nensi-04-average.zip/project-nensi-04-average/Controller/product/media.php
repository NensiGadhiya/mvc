<?php
require_once 'Controller/Core/Action.php';
require_once 'Model/Product_Media.php';
require_once 'Model/Core/Message.php';
require_once 'Model/Media/Row.php';

/**
 * 
 */
class Controller_Product_Media extends Controller_Core_Action
{
	
	protected $productMedia = [];
	protected $mediaRow = null;
	protected $mediaId = null;

	public function setProductMedia($productMedia)
	{
		$this->productMedia = $productMedia;
		return $this;
	}

	public function getProductMedia()
	{
		return $this->productMedia;
	}

	public function setMediaId($mediaId)
    {
   		$this->mediaId= $mediaId;
		return $this;
    }

    public function getMediaId()
    {
   		return $this->mediaId;
    }


	public function setMediaRow($mediaRow)
	{
		$this->mediaRow = $mediaRow;
		return $this;
	}

	public function getMediaRow()
	{
		if ($this->mediaRow) {
			return $this->mediaRow;
		}
		$mediaRow = new Model_Media_Row();
		$this->setMediaRow($mediaRow);
		return $mediaRow;
	}

	public function gridAction()
	{
		$sql = "SELECT * FROM `media`";
		$media = $this->getMediaRow()->fetchAll($sql);
		if (!$media) {
			throw new Exception("Data not found", 1);
			
		}

		$this->setProductMedia($media);
		$this->getTemplate('product_media/grid.phtml');
	}

	public function addAction()
	{
		$this->getTemplate('product_media/add.phtml');
	}

	public function insertAction()

	 {echo "<pre>";
	 	try{
	 	$request = $this->getRequest();
	 	if (!$request) {
	 		throw new Exception("Invalis Request", 1);
	 	}
	 	$productid = $request->getParam('product_id');
	 	if (!$productid) {				
	 		throw new Exception("ProductId not found", 1);
	 	}
		 $image1=$_FILES['image'];
		 $imagefilename = $image1['name'];
		 $file=$request->getPost('filename');
		 $image['image'] = $imagefilename;
		 $image['filename'] = $file;
		 // print_r($image);
		 // die();

		$this->getMediaRow()->setData($image);
		$data = $this->getMediaRow()->save();
		$id = $data->image_id;
		if (!$id) {
				throw new Exception("InsertId not found", 1);
		}

		// echo "<pre>";
		$filetemp=$image1['tmp_name'];
		$fileseprate=explode('.', $imagefilename);
		$fileextension=$fileseprate[1];
		$name=$id.'.'.$fileextension;
		$uploadimage='View/product_media/image/'.$name;
		$imagename=[];
		$imagename['image'] = $name;
     	 move_uploaded_file( $_FILES['image']['tmp_name'], $uploadimage);

		$data = $this->getMediaRow()->load($id)->setData()->addData('image',$name)->save();
		// print_r($data);
	
		$mesaage = new Model_Core_Message();
	 	$mesaage->addMessage("Image inserted successfully..", Model_Core_Message::SUCCESS);
	    // return $this->redirect("index.php?a=grid&c=product&product_id=$productid");

		}catch (Exception $e) 
		{
		$mesaage = new Model_Core_Message();
 		$mesaage->addMessage("Image not inserted..", Model_Core_Message::FAILURE);
   		return $this->redirect("index.php?a=grid&c=product_media&product_id=$productid");
	}

	}

	public function updateAction()
	{
		// echo "<pre>";
		try {
			    $request= $this->getRequest();
			    if (!$request) {
			    	throw new Exception("Invalid Request", 1);
			    }
			    $productid = $request->getParam('product_id');
			     // print_r($productid);
			    $base = $request->getPost('base');
			    $small = $request->getPost('small');
			    $thumb = $request->getPost('thumbnail');
    			$gallery = $request->getPost('gallery');
			    
			    $data = ['base'=>0,'small'=>0,'thumb'=>0,'gallery'=>0];
			    $condition = ['product_id'=>$productid];
			    $images = $request->getPost();
			    print_r($images);
			    $result = $this->getMediaRow()->setData()->save($data,$condition);
			    
			    	if (array_key_exists('base',$images)) {
			    		$data = ['base'=>1];
			    		print_r($data);
			    		$result = $this->getMediaRow()->setData()->save($data,$images['base']);
					}

			    	$data = ['small'=>1];
			    	$result = $this->getMediaRow()->setData()->save($data,$small);

			    	$data = ['thumb'=>1];
			    	$result = $this->getMediaRow()->setData()->save($data,$thumb);

			    	$data = ['gallery'=>1];

			    	foreach ($gallery as $key => $value) {
			    		$result = $this->getMediaRow()->setData()->save($data,$value);
			    	}

			return $this->redirect("index.php?a=grid&c=product_media&product_id=$productid");
	} catch (Exception $e) {
			$mesaage = new Model_Core_Message();
			$mesaage->addMessage("Image not Found..", Model_Core_Message::FAILURE);
			return $this->redirect("index.php?a=grid&c=product_media&product_id=$productid");

		}
}

}	

?>